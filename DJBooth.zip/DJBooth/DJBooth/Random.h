//
//  Random.h
//  DJBooth
//
//  Created by Andrew Hughes on 5/9/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#ifndef __DJBooth__Random__
#define __DJBooth__Random__

int random_in_range (unsigned int min, unsigned int max);

#endif /* defined(__DJBooth__Random__) */
