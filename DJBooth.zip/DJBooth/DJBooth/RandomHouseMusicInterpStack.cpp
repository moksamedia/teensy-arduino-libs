//
//  RandomHouseMusicInterpStack.cpp
//  DJBooth
//
//  Created by Andrew Hughes on 5/9/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#include "RandomHouseMusicInterpStack.h"
#include "RandomHouseMusicInterp.h"

RandomHouseMusicInterpStack::RandomHouseMusicInterpStack(LedDisplay* display) : Animation(display) {
    abc = 0;
    randomHouseMusicInterp1 = new RandomHouseMusicInterp(display);
    randomHouseMusicInterp2 = new RandomHouseMusicInterp(display);
}

RandomHouseMusicInterpStack::~RandomHouseMusicInterpStack() {
    delete randomHouseMusicInterp1;
    delete randomHouseMusicInterp2;
}

void RandomHouseMusicInterpStack::reset() {
    abc = 0;
}

int RandomHouseMusicInterpStack::getRequestedDelayMicros() {
    return delayMicros;
}

bool RandomHouseMusicInterpStack::animate() {
    
    bool result;
    
    if (abc == 0) {
        result = randomHouseMusicInterp1->animate();
        delayMicros = randomHouseMusicInterp2->getRequestedDelayMicros();
        abc++;
    }
    else if (abc == 1) {
        result = randomHouseMusicInterp2->animate();
        onColor = randomHouseMusicInterp2->getOnColor();
        delayMicros = randomHouseMusicInterp2->getRequestedDelayMicros();
        abc++;
    }
    else {
        display->setAllPixels(onColor);
        abc = 0;
    }
    
}