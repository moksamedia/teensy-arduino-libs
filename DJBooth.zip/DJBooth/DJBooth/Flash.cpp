//
//  Flash.cpp
//  DJBooth
//
//  Created by Andrew Hughes on 5/9/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#include "Flash.h"

Flash::Flash(uint32_t color, int delayMicroseconds, LedDisplay* display) : Animation(display) {
    this->color = color;
    this->delayMicroseconds = delayMicroseconds;
}

bool Flash::animate() {
    display->setAllPixels(color);
    return true;
}

int Flash::getRequestedDelayMicros() {
    return delayMicroseconds;
}

void reset() {
    
}