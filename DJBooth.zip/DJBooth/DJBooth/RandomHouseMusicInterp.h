//
//  RandomHouseMusicInterp.h
//  DJBooth
//
//  Created by Andrew Hughes on 5/9/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#ifndef __DJBooth__RandomHouseMusicInterp__
#define __DJBooth__RandomHouseMusicInterp__

#include "Animation.h"
#include "Interp.h"

class RandomHouseMusicInterp : public Animation {
    
public:
    
    RandomHouseMusicInterp(LedDisplay * display);
    
    bool animate();
    int getRequestedDelayMicros();
    void reset();
    
    int getCurrentCyclePosition();
    uint32_t getOnColor();

private:
    
    int calculateOffset(int currentCyclePosition);
    
    unsigned int delayMicros;
    
    uint32_t onColor;
    uint32_t offColor = 0;
    
    Interp * interp;
    int cycleMax;
    int currentCyclePosition;
    
};

#endif /* defined(__DJBooth__RandomHouseMusicInterp__) */
