//
//  Rainbow.h
//  DJBooth
//
//  Created by Andrew Hughes on 4/30/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#ifndef __DJBooth__Rainbow__
#define __DJBooth__Rainbow__

#include "Arduino.h"
#include "Animation.h"
#include "RainbowData.h"

class Rainbow : public Animation {
public:
    
    // phaseShift is the shift between each row.  phaseShift=0
    // causes all rows to show the same colors moving together.
    // phaseShift=180 causes each row to be the opposite colors
    // as the previous.
    //
    // cycleTime is the number of milliseconds to shift through
    // the entire 360 degrees of the color wheel:
    // Red -> Orange -> Yellow -> Green -> Blue -> Violet -> Red
    //
    Rainbow(unsigned int phaseShift, unsigned int cycleTime, LedDisplay * display);
    ~Rainbow();
    
    bool animate();
    int getRequestedDelayMicros();
    void reset();
    static RainbowData rainbowData;

private:
    unsigned int phaseShift;
    unsigned int cycleTime;
    unsigned int requestedDelay;
    int currentColor = 0;
    int colorMax = 180;
    
};

#endif /* defined(__DJBooth__Rainbow__) */
