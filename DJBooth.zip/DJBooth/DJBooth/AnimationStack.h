//
//  AnimationStack.h
//  DJBooth
//
//  Created by Andrew Hughes on 4/30/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#ifndef __DJBooth__AnimationStack__
#define __DJBooth__AnimationStack__

#include "Arduino.h"
#include "Animation.h"

class AnimationStack : public Animation {
    
private:
    
    unsigned int numAnimations;
    unsigned int indexOfNextPushedAnimation = 0; // used to push animations in sequence
    unsigned int indexOfCurrentAnimation = 0; // used to cycle through animations
    
    /**
     * The animations. The AnimationStack takes ownership of the animations,
     * and calls delete on them in the destructor.
     */
    Animation** animations;
    
public:
    
    AnimationStack(int numAnimations);
    ~AnimationStack();
    
    bool animate();
    int getRequestedDelayMicros();
    void reset();
    
    void push(Animation * toPush);
    
    
    
};

#endif /* defined(__DJBooth__AnimationStack__) */
