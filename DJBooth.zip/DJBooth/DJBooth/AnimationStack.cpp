//
//  AnimationStack.cpp
//  DJBooth
//
//  Created by Andrew Hughes on 4/30/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#include "AnimationStack.h"

AnimationStack::AnimationStack(int numAnimations) : Animation() {
    this->numAnimations = numAnimations;
    animations = new Animation*[numAnimations];
}

AnimationStack::~AnimationStack() {
    
    int i;
    for(i=0;i<numAnimations;i++) {
        delete animations[i];
    }
    
    delete animations;
    
}

void AnimationStack::push(Animation * toPush) {
    
    if (indexOfNextPushedAnimation >= numAnimations) return;
    
    animations[indexOfNextPushedAnimation] = toPush;
    indexOfNextPushedAnimation++;
    
}

void AnimationStack::reset() {
    int i;
    for (i=0;i<numAnimations;i++) {
        animations[i]->reset();
    }
    indexOfCurrentAnimation = 0;
}

int AnimationStack::getRequestedDelayMicros() {
    return animations[indexOfCurrentAnimation]->getRequestedDelayMicros();
}


bool AnimationStack::animate() {
    
    bool animationIsFinished = animations[indexOfCurrentAnimation]->animate();
    
    if (animationIsFinished) {
        
        indexOfCurrentAnimation++;
        
        if (indexOfCurrentAnimation >= numAnimations) {
            return true;
        }
        else {
            return false;
        }
    }

    return animationIsFinished;
    
}
