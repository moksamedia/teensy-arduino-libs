//
//  RandomHouseMusicInterp.cpp
//  DJBooth
//
//  Created by Andrew Hughes on 5/9/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#include "Random.h"
#include "RandomHouseMusicInterp.h"
#include "constants.h"
#include "MicroColor.h"

RandomHouseMusicInterp::RandomHouseMusicInterp(LedDisplay * display) : Animation(display) {
    this->cycleMax = 50;
    interp = new Interp(0,359,this->cycleMax);
    currentCyclePosition = 0;
}

int RandomHouseMusicInterp::calculateOffset(int currentCyclePosition) {
    
    int offset = random_in_range(0, LEDS_PER_STRIP-26);
    
    if ( currentCyclePosition >= cycleMax - 15) {
        offset = random_in_range(10, 30);
    }
    
    if ( currentCyclePosition >= cycleMax - 5) {
        offset = random_in_range(18, 22);
    }
    
    if ( currentCyclePosition == cycleMax - 1) offset = 20;
    
    return offset;
}

void RandomHouseMusicInterp::reset() {
    currentCyclePosition = 0;
}

int RandomHouseMusicInterp::getRequestedDelayMicros() {
    return delayMicros;
}

int RandomHouseMusicInterp::getCurrentCyclePosition() {
    return currentCyclePosition;
}

uint32_t RandomHouseMusicInterp::getOnColor() {
    return onColor;
}

bool RandomHouseMusicInterp::animate() {
    
    int offset = this->calculateOffset(currentCyclePosition);
    
    delayMicros = 250000/cycleMax*currentCyclePosition;

    onColor = MicroColor::makeColor(interp->smooth(currentCyclePosition),80,30);

    drawArray((unsigned int*)&House_Small[0][0], House_Small_Size, offset, onColor, offColor);
    
    currentCyclePosition++;
    
    if (currentCyclePosition == cycleMax) {
        this->reset();
        return true;
    }
    else {
        return false;
    }

}
