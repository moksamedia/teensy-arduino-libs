//
//  Animation.h
//  DJBooth
//
//  Created by Andrew Hughes on 4/26/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#ifndef __DJBooth__Animation__
#define __DJBooth__Animation__

#include "LedDisplay.h"

class Animation {
public:
    
    Animation(LedDisplay * display);
    Animation();
    
    /**
     * This is called each cycle to iterate the animation. The
     * animation is responsible for setting pixels using the display,
     * but NOT showing them, and shouldn't call delay. Showing and
     * delay is controlled in the main loop. Animation should reset
     * when finished and return true;
     */
    virtual bool animate() = 0;
    
    /**
     * If animation would like to request more delay time, return
     * a value in microseconds here.
     */
    virtual int getRequestedDelayMicros() = 0;
    
    /**
     * Should return animation to original state.
     */
    virtual void reset() = 0;
    
protected:
    
    LedDisplay * display;
    
    void drawArray(unsigned int * array, int arraySize, int offset, unsigned int onColor, unsigned int offColor);
    int offsetArray(int x, int y, int offset, unsigned int * array, int arraySize);

    
    
};


#endif /* defined(__DJBooth__Animation__) */
