; //
//  RainbowData.h
//  DJBooth
//
//  Created by Andrew Hughes on 5/1/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#ifndef __DJBooth__RainbowData__
#define __DJBooth__RainbowData__

#include "Arduino.h"

class RainbowData {
public:
    RainbowData(unsigned int colorSteps, unsigned int saturation, unsigned int lightness );
    ~RainbowData();
    uint32_t * colors;
    unsigned int colorSteps;
};

#endif /* defined(__DJBooth__RainbowData__) */
