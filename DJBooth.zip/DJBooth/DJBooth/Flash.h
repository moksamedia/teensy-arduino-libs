//
//  Flash.h
//  DJBooth
//
//  Created by Andrew Hughes on 5/9/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#ifndef __DJBooth__Flash__
#define __DJBooth__Flash__

#include "Animation.h"

class Flash : public Animation {
public:
    
    Flash(uint32_t color, int delayMicroseconds, LedDisplay* display);
    
    bool animate();
    int getRequestedDelayMicros();
    void reset();
    
private:
    
    uint32_t color;
    int delayMicroseconds;
    
};

#endif /* defined(__DJBooth__Flash__) */
