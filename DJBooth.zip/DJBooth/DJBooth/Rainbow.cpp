//
//  Rainbow.cpp
//  DJBooth
//
//  Created by Andrew Hughes on 4/30/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#include "Rainbow.h"
#include "MicroColor.h"
#include "ArdPrint.h"

RainbowData Rainbow::rainbowData = RainbowData(180, 80, 10);

Rainbow::Rainbow(unsigned int phaseShift, unsigned int cycleTime, LedDisplay * display) : Animation(display){
    this->phaseShift = phaseShift;
    this->cycleTime = cycleTime;
}

Rainbow::~Rainbow() {
    
}

void Rainbow::reset() {
    currentColor = 0;
}

bool Rainbow::animate() {
    
    requestedDelay = round(cycleTime * 1000 / LEDS_PER_STRIP);
    
    int x,y;
    
    for (x = 0; x < LEDS_PER_STRIP; x++) {
        for (y = 0; y < LEDS_NUM_STRIPS; y++) {
            int yDelta = int((double)phaseShift / 2.0);
            int index = (currentColor + x + y * yDelta) % colorMax;
            display->setPixel(x + y * LEDS_PER_STRIP, rainbowData.colors[index]);
            //ArdPrint::f("dly = %d, currentColor = %d, phaseShift = %d, yDelta = %d, index = %d", requestedDelay, currentColor, phaseShift, yDelta, index);
        }
    }
    
    
    currentColor++;
    
    if (currentColor > colorMax) {
        reset();
        return true;
    }
    else {
        return false;
    }
    
    
}

int Rainbow::getRequestedDelayMicros() {
    return requestedDelay;
}
