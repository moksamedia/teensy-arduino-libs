//
//  RainbowData.cpp
//  DJBooth
//
//  Created by Andrew Hughes on 5/1/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#include "RainbowData.h"
#include "MicroColor.h"
#include "ArdPrint.h"

RainbowData::RainbowData(unsigned int colorSteps, unsigned int saturation, unsigned int lightness ) {
    
    this->colorSteps = colorSteps;
    
    colors = new uint32_t[colorSteps];
    int hue;
    
    for (int i = 0; i < colorSteps; i++) {
        hue = round(i * 360 / colorSteps);
        colors[i] = MicroColor::makeColor(hue, saturation, lightness);
    }
    
}

RainbowData::~RainbowData() {
    delete colors;
}