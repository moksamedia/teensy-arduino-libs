//
//  RandomHouseMusicInterpStack.h
//  DJBooth
//
//  Created by Andrew Hughes on 5/9/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#ifndef __DJBooth__RandomHouseMusicInterpStack__
#define __DJBooth__RandomHouseMusicInterpStack__

#include "Animation.h"
#include "RandomHouseMusicInterp.h"
#include "Flash.h"

class RandomHouseMusicInterpStack : public Animation {
public:
    
    RandomHouseMusicInterpStack(LedDisplay* display);
    ~RandomHouseMusicInterpStack();
    
    bool animate();
    int getRequestedDelayMicros();
    void reset();
    
private:
    
    
    uint8_t abc;
    
    unsigned int delayMicros;
    uint32_t onColor;
    
    RandomHouseMusicInterp * randomHouseMusicInterp1;
    RandomHouseMusicInterp * randomHouseMusicInterp2;
    
};

#endif /* defined(__DJBooth__RandomHouseMusicInterpStack__) */
