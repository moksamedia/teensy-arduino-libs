//
//  Animation.cpp
//  DJBooth
//
//  Created by Andrew Hughes on 4/26/15.
//  Copyright (c) 2015 Andrew Hughes. All rights reserved.
//

#include "Animation.h"

Animation::Animation() {
    // Do nothing, used by animation stack
}

Animation::Animation(LedDisplay * display) {
    this->display = display;
}


void Animation::drawArray(unsigned int * array, int arraySize, int offset, unsigned int onColor, unsigned int offColor) {
    
    int x, y, val;
    
    // Iterate over the rows
    for (y=0;y<8;y++) {
        
        // Iterate through the columns
        for (x=0;x<LEDS_PER_STRIP;x++) {
            
            val = offsetArray(x,y,offset,array,arraySize);
            
            if ( val == 1 ) {
                display->setPixel(x + y*LEDS_PER_STRIP, onColor);
            }
            else {
                display->setPixel(x + y*LEDS_PER_STRIP, offColor);
            }
        }
    }
}

int Animation::offsetArray(int x, int y, int offset, unsigned int * array, int arraySize)
{
    if (x < offset) {
        return 0;
    }
    else if (x >= offset + arraySize) {
        return 0;
    }
    else {
        return *(array + y * arraySize + x - offset); 
    }
}