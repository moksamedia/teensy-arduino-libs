
  DJBooth
  Project
  ----------------------------------
  Developed with embedXcode

  Project DJBooth
  Created by Andrew Hughes on 4/26/15
  Copyright © 2015 Andrew Hughes
  License <#license#>



  References
  ----------------------------------



  embedXcode
  embedXcode+
  ----------------------------------
  Embedded Computing on Xcode
  Copyright © Rei VILO, 2010-2015
  All rights reserved
  http://embedXcode.weebly.com

